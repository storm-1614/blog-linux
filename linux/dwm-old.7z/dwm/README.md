# dwm
### 安装
``` bash
sudo make clean install
```
### 使用软件
rofi,picom,alacritty